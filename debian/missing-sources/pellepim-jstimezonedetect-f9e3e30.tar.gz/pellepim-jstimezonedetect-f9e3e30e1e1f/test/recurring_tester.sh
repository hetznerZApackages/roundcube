#!/bin/bash
while :
do
    clear
    node run.js
    sleep 1
done